﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CandidateProject.ViewModels
{
    public class EquipmentViewModel
    {
        public int Id { get; set; }
        public string ModelType { get; set; }
        public string SerialNumber { get; set; }
    }
}