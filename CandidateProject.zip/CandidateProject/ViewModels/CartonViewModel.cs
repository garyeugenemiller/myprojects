﻿namespace CandidateProject.ViewModels
{
    public class CartonViewModel
    {
        public int Id { get; set; }
        public string CartonNumber { get; set; }

        public int numItems { get; set; }
    }
}